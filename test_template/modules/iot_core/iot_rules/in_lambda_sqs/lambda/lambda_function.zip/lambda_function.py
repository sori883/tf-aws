def handler(event, context):
    print('ping_pong')

    return()